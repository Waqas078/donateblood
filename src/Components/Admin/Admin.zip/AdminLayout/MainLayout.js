import React from "react";
import { Link } from "react-router-dom";
import { Layout, Menu } from "antd";
import { Outlet } from "react-router-dom";
import "./Main.css";
// import "antd/dist/antd.css";
// import "antd/dist/reset.css";
import "antd/dist/reset.css";
const { Header, Content, Sider } = Layout;

function MainLayout() {
  return (
    <Layout>
      <Header className="header" style={{ height: "65px" }}>
        <div>
          <h1
            style={{
              color: "white",
              float: "left",
              fontSize: "35px",
              marginLeft: "-30px",
            }}
          >
            <img src={require("./droop.png")} style={{ width: "38px" }} />
            DonateBlood.pk
          </h1>
        </div>
      </Header>
      <Layout>
        <Sider
          style={{ height: "100vh" }}
          width={200}
          breakpoint="lg"
          collapsedWidth="0"
          onBreakpoint={(broken) => {
            console.log(broken);
          }}
          onCollapse={(collapsed, type) => {
            console.log(collapsed, type);
          }}
        >
          <Menu
            className="AdminMenu"
            mode="inline"
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            style={{
              height: "100%",
              borderRight: 0,
            }}
            items={[
              {
                key: "1",
                label: (
                  <Link
                    to="/bloodbank/Dashboard"
                    className="Linkss"
                    style={{ textDecoration: "none" }}
                  >
                    Dashboard
                  </Link>
                ),
              },
              {
                key: "2",
                label: (
                  <Link
                    to="/bloodbank/Adminprofile"
                    style={{ textDecoration: "none" }}
                  >
                    Admin Profile
                  </Link>
                ),
              },

              {
                key: "3",
                label: (
                  <Link
                    to="/bloodbank/Members"
                    style={{ textDecoration: "none" }}
                  >
                    Members
                  </Link>
                ),
              },
              {
                key: "4",
                label: (
                  <Link
                    to="/bloodbank/Bloodbanks"
                    style={{ textDecoration: "none" }}
                  >
                    Blood banks
                  </Link>
                ),
              },
              {
                key: "5",
                label: (
                  <Link
                    to="/bloodbank/Hospitals"
                    style={{ textDecoration: "none" }}
                  >
                    Hospitals
                  </Link>
                ),
              },
              {
                key: "5",
                label: (
                  <Link
                    to="/bloodbank/UploadAnnoucenmnet"
                    style={{ textDecoration: "none" }}
                  >
                    UploadAnnoucenmnets
                  </Link>
                ),
              },
              {
                key: "6",
                label: (
                  <Link
                    to="/bloodbank/addRecord"
                    style={{ textDecoration: "none" }}
                  >
                    Chats
                  </Link>
                ),
              },
              {
                key: "7",
                label: "Logout",
              },
            ]}
          />
        </Sider>
        <Layout
          className="Layout"
          style={{
            padding: "0 24px 24px",
            background:
              "linear-gradient(to right, rgba(235, 169, 179, 0.58), rgba(152, 11, 33, 0.98))",
          }}
        >
          <Content
            className="Content-top"
            style={{
              padding: 24,
              minHeight: 280,
              background: "white",
            }}
          >
            <Outlet />
          </Content>
        </Layout>
      </Layout>
    </Layout>
  );
}

export default MainLayout;
